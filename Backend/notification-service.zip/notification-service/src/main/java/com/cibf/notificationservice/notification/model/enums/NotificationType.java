package com.cibf.notificationservice.notification.model.enums;

public enum NotificationType {
    RESERVATION_CONFIRMATION,
    RESERVATION_CANCELLATION,
    REGISTRATION_CONFIRMATION,
    PASSWORD_RESET,
    ADMIN_ALERT
}
